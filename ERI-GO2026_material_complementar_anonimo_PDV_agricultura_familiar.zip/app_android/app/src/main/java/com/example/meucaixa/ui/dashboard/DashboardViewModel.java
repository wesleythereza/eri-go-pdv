package com.example.meucaixa.ui.dashboard;

import com.example.meucaixa.database.AppDatabase;
import com.example.meucaixa.database.SaleDao;
import com.example.meucaixa.models.Sale;
import com.example.meucaixa.utils.SessionManager;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import java.util.List;

public class DashboardViewModel extends AndroidViewModel {

    private final SaleDao saleDao;
    private final long userId;

    public DashboardViewModel(Application application) {
        super(application);
        AppDatabase db = AppDatabase.getDatabase(application);
        saleDao = db.saleDao();
        
        SessionManager sessionManager = new SessionManager(application);
        userId = sessionManager.getLoggedInUserId();
    }

    public LiveData<List<Sale>> getSalesForDay(long startOfDay, long endOfDay) {
        return saleDao.getSalesForDay(userId, startOfDay, endOfDay);
    }
}

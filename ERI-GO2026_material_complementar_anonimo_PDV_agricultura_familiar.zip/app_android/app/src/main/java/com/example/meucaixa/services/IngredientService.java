package com.example.meucaixa.services;

import android.app.Application;
import androidx.lifecycle.LiveData;

import com.example.meucaixa.database.AppDatabase;
import com.example.meucaixa.database.IngredientDao;
import com.example.meucaixa.models.Ingredient;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class IngredientService {
    private final IngredientDao ingredientDao;
    private final ExecutorService executorService;

    public IngredientService(Application application) {
        AppDatabase db = AppDatabase.getDatabase(application);
        this.ingredientDao = db.ingredientDao();
        this.executorService = Executors.newSingleThreadExecutor();
    }

    public LiveData<List<Ingredient>> getAllIngredients(long userId) {
        return ingredientDao.getAllIngredients(userId);
    }

    public void insert(Ingredient ingredient) {
        executorService.execute(() -> ingredientDao.insert(ingredient));
    }
    
    public Ingredient getIngredientById(long id) {
        return ingredientDao.getIngredientById(id);
    }
}

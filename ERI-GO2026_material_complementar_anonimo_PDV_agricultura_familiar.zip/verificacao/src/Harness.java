import com.example.meucaixa.database.*; import com.example.meucaixa.models.*; import com.example.meucaixa.services.SaleService;
import com.example.meucaixa.ui.sales.NewSaleViewModel;
import androidx.lifecycle.LiveData; import androidx.room.RoomDatabase; import java.util.*; import java.util.concurrent.*;

public class Harness {
  // ---------- in-memory store with snapshot/rollback ----------
  static Map<Long,Product> P=new LinkedHashMap<>(); static Map<Long,Ingredient> I=new LinkedHashMap<>();
  static List<ProductIngredient> PI=new ArrayList<>(); static List<Sale> S=new ArrayList<>(); static List<SaleItem> SI=new ArrayList<>();
  static Map<Long,double[]> snapP, snapI; static int snapS, snapSI; static boolean failItems=false; static long nextSale=1;
  static void snap(){ snapP=new HashMap<>(); P.forEach((k,v)->snapP.put(k,new double[]{v.getStock()})); snapI=new HashMap<>(); I.forEach((k,v)->snapI.put(k,new double[]{v.getCurrentStock()})); snapS=S.size(); snapSI=SI.size(); }
  static void rollback(){ P.forEach((k,v)->v.setStock(snapP.get(k)[0])); I.forEach((k,v)->v.setCurrentStock(snapI.get(k)[0])); while(S.size()>snapS)S.remove(S.size()-1); while(SI.size()>snapSI)SI.remove(SI.size()-1); }
  static Product copy(Product p){ Product q=new Product(); q.setId(p.getId()); q.setUserId(p.getUserId()); q.setName(p.getName()); q.setPrice(p.getPrice()); q.setStock(p.getStock()); q.setUnitType(p.getUnitType()); q.setOwnProduction(p.isOwnProduction()); q.setCostPrice(p.getCostPrice()); return q; }

  static class FakeProductDao implements ProductDao {
    public LiveData<List<Product>> getAll(long u){return null;} public LiveData<List<Product>> searchByName(long u,String q){return null;}
    public Product getByIdSynchronous(long id,long u){ Product p=P.get(id); return p==null?null:copy(p); }
    public LiveData<Product> getById(long id,long u){return null;} public long insert(Product p){P.put(p.getId(),p);return p.getId();}
    public void update(Product p){ P.put(p.getId(),copy(p)); } public void deleteById(long id){P.remove(id);} }
  static class FakeIngredientDao implements IngredientDao {
    public long insert(Ingredient i){I.put(i.getId(),i);return i.getId();} public void update(Ingredient i){I.put(i.getId(),i);} public void delete(Ingredient i){I.remove(i.getId());}
    public LiveData<List<Ingredient>> getAllIngredients(long u){return null;} public Ingredient getIngredientById(long id){return I.get(id);} }
  static class FakePIDao implements ProductIngredientDao {
    public void insert(ProductIngredient p){PI.add(p);} public void insertAll(List<ProductIngredient> l){PI.addAll(l);} public void update(ProductIngredient p){} public void delete(ProductIngredient p){PI.remove(p);}
    public LiveData<List<ProductIngredient>> getIngredientsForProduct(long id){return null;}
    public List<ProductIngredient> getIngredientsForProductSynchronous(long id){ List<ProductIngredient> r=new ArrayList<>(); for(ProductIngredient p:PI) if(p.getProductId()==id) r.add(p); return r; }
    public void deleteIngredientsForProduct(long id){PI.removeIf(p->p.getProductId()==id);} public LiveData<List<RecipeIngredientDetail>> getRecipeDetailsForProduct(long id){return null;} }
  static class FakeSaleDao extends SaleDao {
    public long insertSale(Sale s){ s.setId(nextSale++); S.add(s); return s.getId(); }
    public void insertSaleItems(List<SaleItem> l){ if(failItems) throw new RuntimeException("SQLiteFullException (falha de E/S injetada)"); SI.addAll(l); }
    public LiveData<List<Sale>> getSalesForDay(long u,long a,long b){return null;} public LiveData<List<Sale>> getSalesForMonth(long u,long a,long b){return null;} }
  static class FakeDb extends AppDatabase {
    ProductDao pd=new FakeProductDao(); IngredientDao id=new FakeIngredientDao(); ProductIngredientDao pid=new FakePIDao(); SaleDao sd=new FakeSaleDao();
    public UserDao userDao(){return null;} public ProductDao productDao(){return pd;} public SaleDao saleDao(){return sd;}
    public IngredientDao ingredientDao(){return id;} public ProductIngredientDao productIngredientDao(){return pid;} public ReportsDao reportsDao(){return null;} }

  static Product prod(long id,String n,double price,double stock,String unit,boolean own,double cost){ Product p=new Product(); p.setId(id); p.setUserId(1); p.setName(n); p.setPrice(price); p.setStock(stock); p.setUnitType(unit); p.setOwnProduction(own); p.setCostPrice(cost); P.put(id,p); return p; }
  static Ingredient ing(long id,String n,double price,double qty,double stock){ Ingredient i=new Ingredient(); i.setId(id); i.setUserId(1); i.setName(n); i.setPackagePrice(price); i.setPackageQuantity(qty); i.setCurrentStock(stock); i.setUnitOfMeasure("Kg/g"); I.put(id,i); return i; }
  static void reset(){ P.clear(); I.clear(); PI.clear(); S.clear(); SI.clear(); failItems=false; android.util.Log.LOG.clear(); }

  /** Executa o checkout real e devolve se o callback de sucesso foi chamado; espera o executor terminar. */
  static boolean checkout(SaleService svc,double total,double cost,List<SaleItem> items) throws Exception {
    CountDownLatch done=new CountDownLatch(1); boolean[] ok={false};
    svc.processCheckoutAsync(1L,total,cost,items,()->{ok[0]=true;});
    // segunda tarefa no mesmo executor single-thread: só roda após o checkout
    java.lang.reflect.Field f=SaleService.class.getDeclaredField("executorService"); f.setAccessible(true);
    ((ExecutorService)f.get(svc)).execute(done::countDown); done.await(5,TimeUnit.SECONDS); return ok[0]; }
  static String r(double x){ return String.format(Locale.ROOT,"%.6f",x); }
  static StringBuilder J=new StringBuilder("[\n"); static int n=0;
  static void out(String id,String titulo,String esperado,String observado,boolean defeito){
    System.out.printf("%s | %s%n   esperado: %s%n   observado: %s%n   => %s%n",id,titulo,esperado,observado,defeito?"DEFEITO CONFIRMADO":"conforme");
    J.append(n++>0?",\n":"").append(String.format("{\"id\":\"%s\",\"titulo\":\"%s\",\"esperado\":\"%s\",\"observado\":\"%s\",\"defeito\":%b}",id,titulo,esperado,observado.replace("\"","'"),defeito)); }

  public static void main(String[] a) throws Exception {
    FakeDb db=new FakeDb(); RoomDatabase.Builder.INSTANCE=db; RoomDatabase.onTxBegin=Harness::snap; RoomDatabase.onTxRollback=Harness::rollback;
    android.app.Application app=new android.app.Application();

    // E1 — venda acima do estoque (unidade)
    reset(); SaleService svc=new SaleService(app); prod(1,"Maçã",0.25,4,"un",false,0.10);
    boolean ok=checkout(svc,6*0.25,0.0,List.of(new SaleItem(0,1,"Maçã",0.25,0,6)));
    out("E1","Venda de 6 un. com estoque 4","rejeitar ou alertar; estoque nunca oculta deficit",
        "venda gravada="+(S.size()==1)+", sucesso="+ok+", qtd vendida="+SI.get(0).getQuantity()+", estoque final="+P.get(1L).getStock()+" (deficit de 2 un. apagado)", ok && P.get(1L).getStock()==0);

    // E2 — custo no cabeçalho da venda (o fragmento envia totalCost=0)
    double somaItens=0; for(SaleItem s:SI) somaItens+=s.getCostPrice()*s.getQuantity();
    out("E2","Custo total do cabeçalho vs. soma dos itens","sales.totalCost = soma(custo x qtd) = "+r(somaItens),
        "sales.totalCost="+S.get(0).getTotalCost(), S.get(0).getTotalCost()!=somaItens);

    // E3 — custo de produção própria (bolo de mandioca) com insumo por peso e por unidade
    reset(); svc=new SaleService(app); prod(2,"Bolo de mandioca",25.0,2,"un",true,0);
    ing(10,"Farinha de mandioca",8.00,1.000,5.000);   // R$ 8,00 o pacote de 1 kg
    ing(11,"Ovos (dúzia)",9.00,0.012,0.024);           // digitado '12' -> WeightTextWatcher/1000 -> 0,012
    PI.add(new ProductIngredient(2,10,0.020)); PI.add(new ProductIngredient(2,11,0.003)); // 20 g; '3' ovos -> 0,003
    ok=checkout(svc,50.0,0.0,List.of(new SaleItem(0,2,"Bolo de mandioca",25.0,0,2)));
    double esp=8.0/1.0*0.020+9.0/0.012*0.003;
    out("E3","Custo unitário de item de produção própria","R$ "+r(esp)+" (0,16 farinha + 2,25 ovos)",
        "costPrice gravado=R$ "+r(SI.get(0).getCostPrice())+"; farinha="+r(I.get(10L).getCurrentStock())+" kg; ovos='"+String.format(new Locale("pt","BR"),"%.3f",I.get(11L).getCurrentStock())+"' na tela (18 ovos)",
        Math.abs(SI.get(0).getCostPrice()-esp)>1e-9);

    // E4 — falha de persistência após a UI já ter anunciado sucesso
    reset(); svc=new SaleService(app); prod(3,"Queijo minas",40.0,5,"kg/g",false,22.0); failItems=true;
    ok=checkout(svc,40.0,0.0,List.of(new SaleItem(0,3,"Queijo minas",40.0,0,1)));
    String err=android.util.Log.LOG.stream().filter(s->s.startsWith("E")).findFirst().orElse("-");
    out("E4","Falha de E/S durante a gravação dos itens","usuário informado da falha; venda não perdida",
        "rollback="+(S.isEmpty()&&P.get(3L).getStock()==5.0)+", callback de sucesso="+ok+", callback de erro=inexistente na API; único registro: log interno. NewSaleFragment já exibiu 'Venda salva com sucesso!'", !ok);

    // E5 — venda por peso pelo caminho real da UI (NewSaleFragment.addProductToCart -> addItemToCart(p, 1.0); CartAdapter +/-1)
    reset(); prod(4,"Tomate",6.00,10.0,"kg/g",false,3.0); NewSaleViewModel vm=new NewSaleViewModel(app);
    vm.addItemToCart(P.get(4L),1.0);              // único valor que o fragmento envia
    SaleItem it=vm.getCartItemsAsList().get(0); it.setQuantity(it.getQuantity()+1); it.setQuantity(it.getQuantity()-1); // botões + e - do CartAdapter
    out("E5","Venda de 0,350 kg de tomate a R$ 6,00/kg","quantidade 0,350 kg; total R$ 2,10",
        "quantidades alcançáveis pela UI = {1, 2, 3, ...}; menor venda possível = "+it.getQuantity()+" kg = R$ "+r(it.getQuantity()*it.getProductPrice()), true);

    // E6 — precisão: soma de valores monetários em double
    reset(); svc=new SaleService(app); prod(5,"Cheiro-verde",0.10,100,"un",false,0.05); prod(6,"Couve",0.20,100,"un",false,0.05);
    double tot=0; for(int k=0;k<1;k++){ tot+=0.10*1; tot+=0.20*1; }
    ok=checkout(svc,tot,0.0,List.of(new SaleItem(0,5,"Cheiro-verde",0.10,0,1),new SaleItem(0,6,"Couve",0.20,0,1)));
    out("E6","Total monetário em ponto flutuante binário","0.30 exato (BigDecimal/centavos)","sales.totalPrice="+S.get(0).getTotalPrice(), S.get(0).getTotalPrice()!=0.30);

    J.append("\n]\n"); java.nio.file.Files.writeString(java.nio.file.Path.of(a[0]),J.toString()); System.exit(0);
  }
}

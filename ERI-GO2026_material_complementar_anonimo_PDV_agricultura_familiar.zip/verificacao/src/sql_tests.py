"""Executa as consultas @Query reais (extraídas do código-fonte) em SQLite com o esquema derivado das entidades."""
import re, sqlite3, sys, json
R = sys.argv[1]
def queries(path):
    src = open(path, encoding='utf-8').read()
    out = {}
    for m in re.finditer(r'@Query\(((?:\s*"[^"]*"\s*\+?)+)\)\s*[\w<>, ]+?\s(\w+)\(', src):
        sql = ''.join(re.findall(r'"([^"]*)"', m.group(1))); out[m.group(2)] = sql
    return out
pq = queries(f'{R}/database/ProductDao.java'); rq = queries(f'{R}/database/ReportsDao.java')
db = sqlite3.connect(':memory:')
db.executescript('''
CREATE TABLE products(id INTEGER PRIMARY KEY, user_id INT, product_name TEXT, product_price REAL, product_stock REAL, unit_type TEXT, is_own_production INT, cost_price REAL);
CREATE TABLE sales(id INTEGER PRIMARY KEY, user_id INT, date INT, totalPrice REAL, totalCost REAL);
CREATE TABLE sale_items(saleId INT, productId INT, productName TEXT, productPrice REAL, costPrice REAL, quantity REAL, PRIMARY KEY(saleId, productId));''')
def run(sql, **p):
    sql2 = re.sub(r':(\w+)', lambda m: '?', sql); args = [p[k] for k in re.findall(r':(\w+)', sql)]
    return db.execute(sql2, args).fetchall()
res = []
# S1: produto que esgota some do catálogo e da busca (não pode ser reabastecido pela UI)
db.executemany('INSERT INTO products VALUES (?,?,?,?,?,?,?,?)', [
    (1,1,'Maçã',0.25,4,'un',0,0.10), (2,1,'Pequi (kg)',12,0,'kg/g',0,5), (3,1,'Bolo de mandioca',25,0,'un',1,0)])
lista = [r[2] for r in run(pq['getAll'], userId=1)]; busca = [r[2] for r in run(pq['searchByName'], userId=1, query='%Pequi%')]
res.append({'id':'S1','titulo':'Produto sazonal sem receita com estoque 0 (Pequi, kg)','esperado':'continua listado para reposição',
            'observado':f'getAll={lista}; busca por Pequi={busca}','defeito': 'Pequi (kg)' not in lista})
# S3: 'Excluir' (AddEditProductViewModel.deleteProduct) apenas zera o estoque; produto de produção própria permanece listado
res.append({'id':'S3','titulo':'Produto de produção própria após Excluir (estoque 0)','esperado':'deixa de ser listado',
            'observado':f'getAll={lista}','defeito': 'Bolo de mandioca' in lista})
# S2: "Lucro líquido" = receita - CMV (margem bruta); despesas não entram
db.execute('INSERT INTO sales VALUES (1,1,1000,100.0,0.0)')
db.executemany('INSERT INTO sale_items VALUES (?,?,?,?,?,?)', [(1,1,'Maçã',0.25,0.10,200),(1,3,'Bolo de mandioca',25,2.41,2)])
v = run(rq['getNetProfitForPeriod'], userId=1, startTime=0, endTime=2000)[0][0]
hdr = db.execute('SELECT totalPrice-totalCost FROM sales').fetchone()[0]
res.append({'id':'S2','titulo':'Indicador rotulado LUCRO LÍQUIDO','esperado':'lucro líquido exige despesas (feira, transporte, embalagem, taxas)',
            'observado':f'consulta = receita - CMV = R$ {v:.2f} (margem bruta); cabeçalho totalPrice-totalCost = R$ {hdr:.2f}','defeito':True})
for r in res: print(r)
json.dump({'consultas': {**{'ProductDao.'+k:v for k,v in pq.items()}, **{'ReportsDao.'+k:v for k,v in rq.items()}}, 'casos': res},
          open(sys.argv[2],'w'), ensure_ascii=False, indent=1)

package android.util; public class Log { public static java.util.List<String> LOG=new java.util.ArrayList<>();
 public static int d(String t,String m){LOG.add("D "+m);return 0;} public static int e(String t,String m){LOG.add("E "+m);return 0;} public static int e(String t,String m,Throwable x){LOG.add("E "+m+" :: "+x);return 0;} }

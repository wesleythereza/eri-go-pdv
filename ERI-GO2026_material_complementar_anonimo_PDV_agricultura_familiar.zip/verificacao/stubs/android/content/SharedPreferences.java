package android.content; public class SharedPreferences { public long getLong(String k,long d){ return 1L; } }

package androidx.sqlite.db; public interface SupportSQLiteDatabase { void execSQL(String s); }

package androidx.lifecycle; public class Transformations { public static <X,Y> LiveData<Y> switchMap(LiveData<X> s, java.util.function.Function<X,LiveData<Y>> f){ return new LiveData<Y>(); } }

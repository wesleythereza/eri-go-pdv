package androidx.lifecycle; public class LiveData<T> { protected T v; public T getValue(){return v;} }

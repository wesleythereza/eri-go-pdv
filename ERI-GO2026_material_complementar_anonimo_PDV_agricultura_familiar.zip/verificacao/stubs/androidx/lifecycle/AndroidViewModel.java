package androidx.lifecycle; public class AndroidViewModel { public AndroidViewModel(android.app.Application a){} }

package androidx.room; public @interface Index { String[] value() default {}; }

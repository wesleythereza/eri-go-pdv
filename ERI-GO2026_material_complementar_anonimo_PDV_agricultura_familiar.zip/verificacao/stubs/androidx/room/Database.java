package androidx.room; public @interface Database { Class<?>[] entities(); int version(); boolean exportSchema() default true; }

package androidx.room; public @interface OnConflictStrategy { int REPLACE=1; int ABORT=3; int IGNORE=5; }

package androidx.room;
public abstract class RoomDatabase {
  public static Runnable onTxBegin, onTxRollback;
  public void runInTransaction(Runnable r){ if(onTxBegin!=null) onTxBegin.run(); try { r.run(); } catch(RuntimeException e){ if(onTxRollback!=null) onTxRollback.run(); throw e; } }
  public static class Builder<T extends RoomDatabase> { public static Object INSTANCE;
    public Builder<T> addMigrations(Object... m){return this;} public Builder<T> fallbackToDestructiveMigration(){return this;}
    @SuppressWarnings("unchecked") public T build(){ return (T) INSTANCE; } }
}

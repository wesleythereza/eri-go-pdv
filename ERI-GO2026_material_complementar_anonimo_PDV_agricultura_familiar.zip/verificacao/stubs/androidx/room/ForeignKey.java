package androidx.room; public @interface ForeignKey { Class<?> entity(); String[] parentColumns(); String[] childColumns(); int onDelete() default 1; int CASCADE=5; int RESTRICT=2; }

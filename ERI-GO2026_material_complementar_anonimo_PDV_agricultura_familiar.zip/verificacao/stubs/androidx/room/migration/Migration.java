package androidx.room.migration; public abstract class Migration { public Migration(int a,int b){} public abstract void migrate(androidx.sqlite.db.SupportSQLiteDatabase db); }

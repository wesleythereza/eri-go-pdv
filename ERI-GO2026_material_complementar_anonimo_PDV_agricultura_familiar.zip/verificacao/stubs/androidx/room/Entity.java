package androidx.room; public @interface Entity { String tableName() default ""; String[] primaryKeys() default {}; ForeignKey[] foreignKeys() default {}; Index[] indices() default {}; }
